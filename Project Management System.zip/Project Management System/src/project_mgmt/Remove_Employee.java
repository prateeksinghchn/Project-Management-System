
package project_mgmt;

import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

class Remove_Employee implements ActionListener{
    JFrame f;
    JTextField t;
    JLabel l1,l2,l3,l4,l5,l6,l7,l8;
    JButton b,b1,b2,b3;
    JTable table;
    Remove_Employee(){
        f=new JFrame("Remove Project");
        f.setBackground(Color.black);  
        f.setLayout(null);

        l5=new JLabel();
        l5.setBounds(0,0,700,600);
        l5.setLayout(null);
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("project_mgmt/icons/remove.jpg"));
        Image i2 = i1.getImage().getScaledInstance(700,600,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        l5.setIcon(i3);
        f.add(l5);

       //**********FOR SEARCH********//
        l1=new JLabel("Project Id");
        l1.setBounds(50,50,250,30);
        l1.setForeground(Color.white);
        Font f2 = new Font("serif",Font.BOLD,25);
        l1.setFont(f2);
        l5.add(l1);

        t=new JTextField();
        t.setBounds(250,50,150,30);
        l5.add(t);
        //****

        b=new JButton("Search");
        b.setBounds(200,100,100,30);
        b.addActionListener(this);
        l5.add(b);

        b3=new JButton("Back");
        b3.setBounds(360,100,100,30);  
        b3.addActionListener(this);
        l5.add(b3);
        
        //********END OF SEARCH********//
        l2=new JLabel("Project Name:");
        l2.setBounds(50,150,250,30);
        l2.setForeground(Color.white);
        Font f3 = new Font("serif",Font.BOLD,20);
        l2.setFont(f3);
        l5.add(l2);

        l6=new JLabel();   
        l6.setBounds(200,150,350,30);
        l6.setForeground(Color.white);
        Font F6=new Font("serif",Font.BOLD,20);
        l6.setFont(F6);
        l5.add(l6);
        //********//
        l3=new JLabel("Project Description:");
        l3.setBounds(50,200,180,30);
        l3.setForeground(Color.white);
        Font f4 = new Font("serif",Font.BOLD,20);
        l3.setFont(f4);
        l5.add(l3);


        l7=new JLabel();
        l7.setBounds(250,200,450,30);
        l7.setForeground(Color.white);
        Font F7=new Font("serif",Font.BOLD,20);
        l7.setFont(F7);
        l5.add(l7);

        //**********//

        
        l4=new JLabel("Members:");
        l4.setBounds(50,250,250,30);
        l4.setForeground(Color.white);
        Font F5=new Font("serif",Font.BOLD,20);
        l4.setFont(F5);
        l5.add(l4);
        
        table=new JTable();
        table.setBounds(200,250,350,100);
        table.setForeground(Color.BLACK);
        Font f8=new Font("serif",Font.BOLD,20);
        table.setFont(f8);
        l5.add(table);
        table.setVisible(false);

 
        b1=new JButton("Remove");
        b1.setBounds(200,500,100,30);
        b1.addActionListener(this);
        l5.add(b1);


        b2=new JButton("Cancel");
        b2.setBounds(360,500,100,30);
        b2.addActionListener(this);
        l5.add(b2);
        l2.setVisible(false);
        l3.setVisible(false);
        l4.setVisible(false);
        b1.setVisible(false);
        b2.setVisible(false);

        f.setSize(700,600);
        f.setLocation(250,50); 
        f.setVisible(true);
    }
   
    public void actionPerformed(ActionEvent ae){

        if(ae.getSource()==b){
            try{
                String str2= "select s.usn,s.sname from student s,project p,works_on w where w.usn=s.usn and w.pid=p.pid and w.pid='"+t.getText()+"' ";
                conn con = new conn(str2);
                String str = "select * from project where pid ='"+t.getText()+"' ";
                ResultSet rs = con.s.executeQuery(str);
           
                int i=0;
                if(rs.next()){
                    
                    String pname1 = rs.getString(2);
                    String descp1 = rs.getString(3);
                    l2.setVisible(true);
                    l3.setVisible(true);
                    l4.setVisible(true);
                    b1.setVisible(true);
                    b2.setVisible(true);   
                    i=1;
                    l6.setText(pname1);
                    l7.setText(descp1);
                    ResultSet rs2 = con.pst.executeQuery(str2);
                    table.setModel(DbUtils.resultSetToTableModel(rs2));
                    table.setVisible(true);
                    
               }
                if(i==0)
                    JOptionPane.showMessageDialog(null,"Id not found");
                                                                             
            }catch(Exception ex){
                JOptionPane.showMessageDialog(null,"Some error occurred while checking the database."+ex);
            }
        }
        if(ae.getSource()==b1){
            try{
                conn con = new conn();

                //String str0 = "delete from works_on where pid='"+t.getText()+"' ";
                //con.s.executeUpdate(str0);
                String str = "delete from student where usn in (select w.usn from project p,works_on w where w.pid=p.pid and w.pid= '"+t.getText()+"')";
                con.s.executeUpdate(str);
                String str1 = "delete from project where pid='"+t.getText()+"' ";
                con.s.executeUpdate(str1);
                JOptionPane.showMessageDialog(null,"deleted successfully");
                f.setVisible(false);
                Remove_Employee d5=new Remove_Employee();
                
            }catch(Exception ex){
                JOptionPane.showMessageDialog(null,"Exception occured while delting record "+ex);
            }
        }
        if(ae.getSource()==b2){
            f.setVisible(false);
            details d=new details();
        }
        if(ae.getSource()==b3){
            f.setVisible(false);
            details d=new details();
        }
    }

    public static void main(String[]ar){
        new Remove_Employee();
    }
}
