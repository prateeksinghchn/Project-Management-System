
package project_mgmt;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import java.awt.event.*;

class Update_Employee implements ActionListener{

    JFrame f;
    JLabel id,id1,id2,id3,id4,id5,id8,id9,id15;
    JTextField t,t1,t2,t3,t4,t5;
    JButton b,b1;
    String pid;
    
    JFrame f2;
    JTextField st;
    JLabel sl,sl5;
    JButton b2,b3;

    Update_Employee(){
        
        f=new JFrame("Update Project details");
        f.setVisible(false);
        f.setSize(900,500);
        f.setLocation(150,100);
        f.setBackground(Color.white);
        f.setLayout(null);

          
        id15=new JLabel();
        id15.setBounds(0,0,900,500);
        id15.setLayout(null);
        ImageIcon img=new ImageIcon(ClassLoader.getSystemResource("project_mgmt/icons/add_employee.jpg"));
        id15.setIcon(img);

        id8 = new JLabel("Update Project Details:");
        id8.setBounds(50,10,500,50);
        id8.setFont(new Font("serif",Font.ITALIC,40));
        id8.setForeground(Color.black);
        id15.add(id8);
        f.add(id15);


        id1 = new JLabel("Project Id:"); 
        id1.setBounds(50,100,100,30);
        id1.setFont(new Font("serif",Font.BOLD,20));
        id15.add(id1);

        t1=new JTextField();
        t1.setBounds(200,100,150,30);
        id15.add(t1);

        id2 = new JLabel("Project Name:");
        id2.setBounds(400,100,200,30);
        id2.setFont(new Font("serif",Font.BOLD,20));
        id15.add(id2);

        t2=new JTextField();
        t2.setBounds(600,100,150,30);
        id15.add(t2);

        id3= new JLabel("Description:");
        id3.setBounds(50,150,100,30);
        id3.setFont(new Font("serif",Font.BOLD,20));
        id15.add(id3);

        t3=new JTextField();
        t3.setBounds(200,150,150,30);
        id15.add(t3);

        id4= new JLabel("MemberUsn:");
        id4.setBounds(400,150,100,30);
        id4.setFont(new Font("serif",Font.BOLD,20));
        id15.add(id4);

        t4=new JTextField();
        t4.setBounds(600,150,150,30);  
        id15.add(t4);

        id5= new JLabel("Member Names:");
        id5.setBounds(50,200,100,30);
        id5.setFont(new Font("serif",Font.BOLD,20));
        id15.add(id5);

        t5=new JTextField();
        t5.setBounds(200,200,150,30);
        id15.add(t5);

        

        b=new JButton("Update");
        b.setBounds(250,400,100,30);
        b.addActionListener(this);
        id15.add(b);

        b1=new JButton("Cancel");
        b1.setBounds(450,400,100,30);
        b1.addActionListener(this);
        id15.add(b1);
//*******************************************//
        f2=new JFrame("Search");
        f2.setBackground(Color.green);
        f2.setLayout(null);

        sl5=new JLabel();
        sl5.setBounds(0,0,500,270);
        sl5.setLayout(null);
        ImageIcon img2=new ImageIcon(ClassLoader.getSystemResource("project_mgmt/icons/view.jpg"));
        sl5.setIcon(img2);


        sl=new JLabel("Project Id");
        sl.setVisible(true);
        sl.setBounds(40,50,250,30);
        sl.setForeground(Color.white);
        Font F1=new Font("serif",Font.BOLD,25);
        sl.setFont(F1);
        sl5.add(sl);
        f2.add(sl5);

        st=new JTextField();
        st.setBounds(240,50,220,30);
        sl5.add(st);

        b2=new JButton("Search");
        b2.setBounds(240,150,100,30);
        b2.addActionListener(this);
        sl5.add(b2);


        b3=new JButton("Cancel");
        b3.setBounds(360,150,100,30);
        b3.addActionListener(this);
        sl5.add(b3);

        f2.setSize(500,270);
        f2.setLocation(450,250);
        f2.setVisible(true);
        
    

    
    } 
    static String usns="";
    static String snames="";
    public void actionPerformed(ActionEvent ae){
        
        if(ae.getSource()==b2){
            usns="";
            snames="";
            int i=0;
            try{
                JOptionPane.showMessageDialog(null,"Only project details like member names, member usn, project name and project description can be changed. Also, the no. of student usns and names must remain the same as previous.");
                pid=st.getText();
                conn con = new conn();
                String str = "select * from project where pid = '"+pid+"'";
                ResultSet rs = con.s.executeQuery(str);
            
                if(rs.next()){
                    f2.setVisible(false);
                    f.setVisible(true);
                    t1.setText(rs.getString(1));
                    t2.setText(rs.getString(2));
                    t3.setText(rs.getString(3));
                    i=1;
                    int n=0;
                    String str2 = "select s.usn,s.sname from student s,project p,works_on w where w.usn=s.usn and w.pid=p.pid and w.pid ='"+pid+"'";
                    ResultSet rs2 = con.s.executeQuery(str2);
                    
                    while(rs2.next())
                    {
                       usns=usns+","+rs2.getString(1);
                       snames=snames+","+rs2.getString(2);
                       n++;
                       
                    }
                    usns=usns.substring(1,usns.length());
                    snames=snames.substring(1,snames.length());
                    t4.setText(usns);
                    t5.setText(snames);
                    if(n==0)
                       JOptionPane.showMessageDialog(null,"Members not found or some error in fetching the values.");
               }
                if(i==0)
                    JOptionPane.showMessageDialog(null,"Id not found");
            
            }
            catch(Exception ex){
                JOptionPane.showMessageDialog(null,"Error Occurred"+ex);
            }
            
        }
        if(ae.getSource()==b1){
        f.setVisible(false);
        details d=new details();
        }
        if(ae.getSource()==b){
        //f2.setVisible(false);
        //f.setVisible(true);
                
                    String a = t1.getText();
                    String bb = t2.getText();
                    String c = t3.getText();
                    String d = t4.getText();
                    String e = t5.getText();
                    String[] OldUsns=usns.split(",");
                    String[] OldNames=snames.split(",");
                    String[] Usns1=d.split(",");
                    String[] Names1=e.split(",");
                    if(Usns1.length==Names1.length && Usns1.length==OldUsns.length)
                    {
                        int flag=1;
                       for(int i=0;i<Usns1.length;i++)
                       {
                            for(int j=i+1;j<Usns1.length;j++)
                            {
                                if(Usns1[i].equalsIgnoreCase(Usns1[j]))
                                {
                                    flag=0;
                                    break;
                                }
                            }
                        } 
                        if(flag==1)
                        {
                 
                            try
                            {
                                conn cc = new conn();
                                for(int k=0;k<Usns1.length;k++)
                                {
                                String str3="update project set pid='"+a+"',pname='"+bb+"',descp='"+c+"' where pid='"+pid+"'";
                                cc.s.executeUpdate(str3);
                                String str4="update works_on set usn='"+Usns1[k]+"',pid='"+a+"' where usn='"+OldUsns[k]+"'";
                                cc.s.executeUpdate(str4);
                                String str5="update student set usn='"+Usns1[k]+"',sname='"+Names1[k]+"' where usn='"+OldUsns[k]+"'";
                                cc.s.executeUpdate(str5);
                                }
                                JOptionPane.showMessageDialog(null,"Database Updated Successfully.");
                                f.setVisible(false);
                                details d1=new details();
                            }
                            catch(Exception ee)
                            {
                                JOptionPane.showMessageDialog(null,"Some Database Error Occurred. It is best not to change the Project Id otherwise, please enter unique value for Project Id. The error is:"+ee);
                                t1.setText(pid);
                            }
                        }
                        else
                        {
                          JOptionPane.showMessageDialog(null,"Please enter only unique values for usns.");  
                        }
                    }
                    else
                        JOptionPane.showMessageDialog(null,"No. of usns and names were not the same as earlier. Make sure that they are same.");
                
                
        }
        
        if(ae.getSource()==b3){
            f2.setVisible(false);
            details d=new details();
        }
        
    }


    public static void main(String[] arg){
        new Update_Employee();
    }
}
     

