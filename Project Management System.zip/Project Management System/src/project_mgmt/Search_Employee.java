
package project_mgmt;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Search_Employee implements ActionListener{
    JFrame f2;
    JTextField st;
    JLabel sl,sl5;
    JButton b2,b3;

    Search_Employee(){
        f2=new JFrame("search");
        f2.setBackground(Color.green);
        f2.setLayout(null);

        sl5=new JLabel();
        sl5.setBounds(0,0,500,270);
        sl5.setLayout(null);
        ImageIcon img=new ImageIcon(ClassLoader.getSystemResource("project_mgmt/icons/view.jpg"));
        sl5.setIcon(img);


        sl=new JLabel("Project Id");
        sl.setVisible(true);
        sl.setBounds(40,50,250,30);
        sl.setForeground(Color.white);
        Font F1=new Font("serif",Font.BOLD,25);
        sl.setFont(F1);
        sl5.add(sl);
        f2.add(sl5);

        st=new JTextField();
        st.setBounds(240,50,220,30);
        sl5.add(st);

        b2=new JButton("Search");
        b2.setBounds(240,150,100,30);
        b2.addActionListener(this);
        sl5.add(b2);


        b3=new JButton("Cancel");
        b3.setBounds(360,150,100,30);
        b3.addActionListener(this);
        sl5.add(b3);

        f2.setSize(500,270);
        f2.setLocation(450,250);
        f2.setVisible(true);
    }

    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==b3){
            f2.setVisible(false);
            details d=new details();
        }
        if(ae.getSource()==b2){
            new Update_Employee();
            f2.setVisible(false);
        }

    }
   
    public static void main(String[]ar){
        new Search_Employee();
    }    
}
