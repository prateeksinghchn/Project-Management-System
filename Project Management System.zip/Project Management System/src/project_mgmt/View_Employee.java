
package project_mgmt;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

class View_Employee implements ActionListener{

    JFrame f;
    JTextField t;
    JLabel l1,l2;
    JButton b,b2;
    
    JFrame f2;
    JLabel aid8,id0,aid0,id1,aid1,id2,aid2,aid9,al4;
    JTable table1;
    String project_id,pname1,descp1;
    JButton b3,b4;
    ImageIcon icon2;


    View_Employee(){
        f=new JFrame("View Project");
        f.setBackground(Color.green);
        f.setLayout(null);

        l1=new JLabel();
        l1.setBounds(0,0,500,270);
        l1.setLayout(null);
        ImageIcon img=new ImageIcon(ClassLoader.getSystemResource("project_mgmt/icons/view.jpg"));
        l1.setIcon(img);


        l2=new JLabel("Project Id");
        l2.setVisible(true);
        l2.setBounds(40,60,250,30);
        l2.setForeground(Color.white);
        Font F1 = new Font("serif",Font.BOLD,30);
        l2.setFont(F1);
        l1.add(l2);
        f.add(l1);


        t=new JTextField();
        t.setBounds(240,60,220,30);
        l1.add(t);

        b=new JButton("Search");
        b.setBounds(240,150,100,30);
        b.addActionListener(this);
        l1.add(b);

        b2=new JButton("Cancel");
        b2.setBounds(360,150,100,30);
        b2.addActionListener(this);
        l1.add(b2);

        f.setSize(500,270);
        f.setLocation(450,250);
        f.setVisible(true);
        //************************************//
        
        f2=new JFrame("Found Project");
        f2.setVisible(false);
        f2.setSize(595,600);
        f2.setLocation(440,100);
        f2.setBackground(Color.white);
        f2.setLayout(null);
        

        aid9=new JLabel();
        aid9.setBounds(0,0,595,600);
        aid9.setLayout(null);
        ImageIcon img2=new ImageIcon(ClassLoader.getSystemResource("project_mgmt/icons/print.jpg"));
        aid9.setIcon(img2);
        

        aid8 = new JLabel("Project Details");
        aid8.setBounds(50,10,250,30);
        f2.add(aid8);
        aid8.setFont(new Font("serif",Font.BOLD,25));
        aid9.add(aid8);
        f2.add(aid9);
        
        id0 = new JLabel("Project Id:");
        id0.setBounds(50,70,120,30);
        id0.setFont(new Font("serif",Font.BOLD,20));
        aid9.add(id0);

        aid0 = new JLabel();
        aid0.setBounds(200,70,200,30);
        aid0.setFont(new Font("serif",Font.BOLD,20));
        aid9.add(aid0);

        id1 = new JLabel("Project Name:");
        id1.setBounds(50,120,100,30);
        id1.setFont(new Font("serif",Font.BOLD,20));
        aid9.add(id1);

        aid1 = new JLabel();
        aid1.setBounds(200,120,300,30);
        aid1.setFont(new Font("serif",Font.BOLD,20));
        aid9.add(aid1);

 
        id2 = new JLabel("Description:");
        id2.setBounds(50,170,450,30);
        id2.setFont(new Font("serif",Font.BOLD,20));
        aid9.add(id2);

        aid2 = new JLabel();
        aid2.setBounds(200,170,300,30);
        aid2.setFont(new Font("serif",Font.BOLD,20));
        aid9.add(aid2);
        
        al4=new JLabel("Members:");
        al4.setBounds(50,250,250,30);
        al4.setForeground(Color.black);
        Font F5=new Font("serif",Font.BOLD,20);
        al4.setFont(F5);
        aid9.add(al4);

        table1=new JTable();
        table1.setBounds(200,250,350,100);
        table1.setForeground(Color.BLACK);
        Font f8=new Font("serif",Font.BOLD,20);
        table1.setFont(f8);
        aid9.add(table1);

        b3=new JButton("Print");
        b3.setBackground(Color.BLACK);
        b3.setForeground(Color.WHITE);
        b3.setBounds(150,470,100,30);
        b3.addActionListener(this);
        aid9.add(b3);

        b4=new JButton("Cancel");
        b4.setBackground(Color.BLACK);
        b4.setForeground(Color.WHITE);
        b4.setBounds(300,470,100,30);
        b4.addActionListener(this);
        aid9.add(b4);

    }
   
    public void actionPerformed(ActionEvent ae){

        if(ae.getSource()==b2){
            f.setVisible(false);
            details d=new details();
        }
        if(ae.getSource()==b3){
            JOptionPane.showMessageDialog(null,"Printed Successfully !");
            f2.setVisible(false);
            details d=new details();
        }
        if(ae.getSource()==b4){
            f2.setVisible(false);
            f.setVisible(true);
            t.setText("");
        }
        if(ae.getSource()==b){
            
            try{
                String pid3=t.getText();
                String str2= "select s.usn,s.sname from student s,project p,works_on w where w.usn=s.usn and w.pid=p.pid and w.pid='"+pid3+"'";
                conn con = new conn(str2);
                String str = "select * from project where pid ='"+pid3+"'";
                ResultSet rs = con.s.executeQuery(str);
           
                int i=0;
                int m=0;
                if(rs.next()){
                    
                    f.setVisible(false);
                    f2.setVisible(true);
                    project_id = rs.getString(1);
                    pname1 = rs.getString(2);
                    descp1 = rs.getString(3);
                    aid0.setText(project_id);
                    aid1.setText(pname1);
                    aid2.setText(descp1);
                    i=1;
                    ResultSet res2 = con.pst.executeQuery(str2);
                    table1.setModel(DbUtils.resultSetToTableModel(res2));
                    m=1;
                    if(m==0)
                    JOptionPane.showMessageDialog(null,"Members not found");
                }
                if(i==0)
                {   JOptionPane.showMessageDialog(null,"Id not found");
                    t.setText("");
                }
                
            }catch(Exception e){
                 JOptionPane.showMessageDialog(null,"Error occurred while accessing database."+e);
            }

            
            
        }

    }

    public static void main(String[]ar){
        View_Employee v=new View_Employee();
    }
}

